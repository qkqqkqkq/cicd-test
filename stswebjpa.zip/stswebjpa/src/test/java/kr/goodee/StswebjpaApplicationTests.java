package kr.goodee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StswebjpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
